
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteConfig } from '../types';
import { INITIAL_SITE_CONFIG } from '../constants';

interface SiteContextType {
  config: SiteConfig;
  updateConfig: (newConfig: Partial<SiteConfig>) => void;
  resetConfig: () => void;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
}

const SiteContext = createContext<SiteContextType | undefined>(undefined);

export const SiteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('abandance_site_config');
    return saved ? JSON.parse(saved) : INITIAL_SITE_CONFIG;
  });
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    localStorage.setItem('abandance_site_config', JSON.stringify(config));
    // Apply dynamic colors to CSS variables
    document.documentElement.style.setProperty('--primary-color', config.design.primaryColor);
    document.documentElement.style.setProperty('--accent-color', config.design.accentColor);
    document.title = config.companyName;
  }, [config]);

  const updateConfig = (newConfig: Partial<SiteConfig>) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
  };

  const resetConfig = () => {
    if (window.confirm("Are you sure you want to reset all site content to defaults? This cannot be undone.")) {
      setConfig(INITIAL_SITE_CONFIG);
    }
  };

  return (
    <SiteContext.Provider value={{ config, updateConfig, resetConfig, isAdmin, setIsAdmin }}>
      {children}
    </SiteContext.Provider>
  );
};

export const useSite = () => {
  const context = useContext(SiteContext);
  if (!context) throw new Error('useSite must be used within a SiteProvider');
  return context;
};
