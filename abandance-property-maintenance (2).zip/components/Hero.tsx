
import React from 'react';
import { ChevronRight, MessageSquare } from 'lucide-react';
import { useSite } from './SiteContext';

const Hero: React.FC = () => {
  const { config } = useSite();
  return (
    <section className="relative h-screen flex items-center overflow-hidden">
      {/* Background Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={config.hero.bgImage} 
          className="w-full h-full object-cover" 
          alt="Background" 
        />
        <div className="absolute inset-0 bg-navy opacity-80"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-navy via-navy to-transparent opacity-60"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-20">
        <div className="max-w-2xl text-white">
          <div className="inline-block px-3 py-1 bg-gold bg-opacity-20 border border-gold border-opacity-30 rounded-full mb-6">
            <span className="text-gold text-xs font-bold uppercase tracking-widest">Reliable • Professional • On Time</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6 animate-in fade-in slide-in-from-left duration-700">
            {config.hero.title}
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-10 leading-relaxed animate-in fade-in slide-in-from-left duration-700 delay-100">
            {config.hero.subtitle}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 animate-in fade-in slide-in-from-bottom duration-700 delay-200">
            <a 
              href="#quote" 
              className="bg-gold hover:bg-opacity-90 text-white px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl hover:scale-105"
            >
              {config.hero.ctaPrimary} <ChevronRight className="w-5 h-5" />
            </a>
            <a 
              href={`https://wa.me/${config.whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white hover:bg-gray-100 text-navy px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-2 transition-all shadow-xl hover:scale-105"
            >
              <MessageSquare className="w-5 h-5 text-green-500" /> {config.hero.ctaSecondary}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
