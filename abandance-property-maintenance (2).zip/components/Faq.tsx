
import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useSite } from './SiteContext';

const Faq: React.FC = () => {
  const { config } = useSite();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gold text-sm font-bold uppercase tracking-widest mb-3">Questions?</h2>
          <h3 className="text-4xl font-bold text-navy mb-4">Frequently Asked</h3>
        </div>

        <div className="space-y-4">
          {config.faqs.map((faq, idx) => (
            <div 
              key={idx} 
              className={`border-2 rounded-2xl overflow-hidden transition-all duration-300 ${openIndex === idx ? 'border-gold bg-gray-50' : 'border-gray-100'}`}
            >
              <button 
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
              >
                <span className="font-bold text-navy text-lg">{faq.question}</span>
                {openIndex === idx ? <ChevronUp className="text-gold" /> : <ChevronDown className="text-gray-400" />}
              </button>
              <div className={`transition-all duration-300 overflow-hidden ${openIndex === idx ? 'max-h-96' : 'max-h-0'}`}>
                <div className="px-6 pb-6 text-gray-600 leading-relaxed">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Faq;
