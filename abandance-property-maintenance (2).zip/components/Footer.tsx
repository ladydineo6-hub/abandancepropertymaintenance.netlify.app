
import React from 'react';
import { useSite } from './SiteContext';

const Footer: React.FC = () => {
  const { config } = useSite();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16 pb-16 border-b border-white border-opacity-10">
          
          <div className="col-span-1 lg:col-span-1">
            <div className="mb-6">
              <span className="text-2xl font-bold tracking-tight">
                {config.companyName.split(' ')[0].toUpperCase()}
              </span>
              <br />
              <span className="text-[10px] uppercase tracking-widest font-semibold text-gold">
                {config.companyName.split(' ').slice(1).join(' ')}
              </span>
            </div>
            <p className="text-gray-400 leading-relaxed mb-6">
              {config.hero.subtitle.substring(0, 120)}...
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Quick Links</h4>
            <ul className="space-y-4 text-gray-400">
              <li><a href="#services" className="hover:text-gold transition-colors">Services</a></li>
              <li><a href="#how-it-works" className="hover:text-gold transition-colors">How It Works</a></li>
              <li><a href="#testimonials" className="hover:text-gold transition-colors">Testimonials</a></li>
              <li><a href="#faq" className="hover:text-gold transition-colors">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Office Hours</h4>
            <ul className="space-y-4 text-gray-400">
              <li className="flex justify-between"><span>Mon – Sat:</span> <span>08:00 – 17:00</span></li>
              <li className="flex justify-between text-gold"><span>Emergency:</span> <span>24/7 Available</span></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-lg">Contact Us</h4>
            <ul className="space-y-4 text-gray-400">
              <li>Phone/WhatsApp: {config.phone}</li>
              <li>Email: {config.email}</li>
              <li>Area: {config.address}</li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-400 space-y-4 md:space-y-0">
          <p>© {currentYear} {config.companyName}. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-gold transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gold transition-colors">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
