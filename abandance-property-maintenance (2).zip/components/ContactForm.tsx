
import React, { useState } from 'react';
import { Send, MapPin, Phone, Mail, Loader2, CheckCircle2 } from 'lucide-react';
import { FORMSPREE_URL } from '../constants';
import { FormStatus } from '../types';
import { useSite } from './SiteContext';

const ContactForm: React.FC = () => {
  const { config } = useSite();
  const [status, setStatus] = useState<FormStatus>(FormStatus.IDLE);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus(FormStatus.SUBMITTING);

    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      const response = await fetch(FORMSPREE_URL, {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (response.ok) {
        setStatus(FormStatus.SUCCESS);
        form.reset();
      } else {
        setStatus(FormStatus.ERROR);
      }
    } catch (error) {
      console.error("Formspree Error:", error);
      setStatus(FormStatus.ERROR);
    }
  };

  return (
    <section id="quote" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <h2 className="text-gold text-sm font-bold uppercase tracking-widest mb-3">Get In Touch</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-navy mb-8">Ready to Fix or Upgrade?</h3>
            <p className="text-gray-600 text-lg mb-12">
              Fill out the form for a free quote, or use the contact details below to speak with us directly. 
              We're here to help you professionally and affordably.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-md flex items-center justify-center text-gold flex-shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-navy">Call / WhatsApp</h4>
                  <p className="text-gray-600 font-medium">{config.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-md flex items-center justify-center text-gold flex-shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-navy">Service Area</h4>
                  <p className="text-gray-600">{config.address}</p>
                </div>
              </div>
              <div className="flex items-start gap-6">
                <div className="w-12 h-12 bg-white rounded-2xl shadow-md flex items-center justify-center text-gold flex-shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-navy">Email Us</h4>
                  <p className="text-gray-600">{config.email}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-gray-100">
            {status === FormStatus.SUCCESS ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12 animate-in zoom-in duration-500">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-2xl font-bold text-navy mb-4">Request Sent!</h4>
                <p className="text-gray-600">Thank you for reaching out. We will get back to you shortly.</p>
                <button 
                  onClick={() => setStatus(FormStatus.IDLE)}
                  className="mt-8 text-gold font-bold hover:underline"
                >
                  Send another request
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-bold text-navy mb-2">Full Name</label>
                    <input 
                      type="text" id="name" name="name" required 
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold focus:border-transparent outline-none transition-all"
                      placeholder="Your Name"
                    />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-bold text-navy mb-2">Phone Number</label>
                    <input 
                      type="tel" id="phone" name="phone" required 
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold focus:border-transparent outline-none transition-all"
                      placeholder={config.phone}
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-bold text-navy mb-2">Email Address</label>
                  <input 
                    type="email" id="email" name="email" required 
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold focus:border-transparent outline-none transition-all"
                    placeholder="you@example.com"
                  />
                </div>
                <div>
                  <label htmlFor="service" className="block text-sm font-bold text-navy mb-2">Service Needed</label>
                  <select 
                    id="service" name="service" required
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold focus:border-transparent outline-none transition-all"
                  >
                    <option value="">Select a service</option>
                    <option value="General Property Maintenance">General Property Maintenance</option>
                    <option value="Plumbing">Plumbing Services</option>
                    <option value="Electrical">Electrical Services</option>
                    <option value="Painting">Painting</option>
                    <option value="Tiling">Tiling</option>
                    <option value="Renovations">Renovations</option>
                    <option value="Roofing & Waterproofing">Roofing & Waterproofing</option>
                    <option value="Carpentry">Carpentry</option>
                    <option value="Emergency Repairs">Emergency Repairs</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-bold text-navy mb-2">Job Description</label>
                  <textarea 
                    id="message" name="message" required rows={4}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-gold focus:border-transparent outline-none transition-all resize-none"
                    placeholder="Tell us about the project or issue..."
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  disabled={status === FormStatus.SUBMITTING}
                  className="w-full bg-navy text-white py-4 rounded-xl font-bold text-lg hover:bg-opacity-90 transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl disabled:opacity-70"
                >
                  {status === FormStatus.SUBMITTING ? (
                    <><Loader2 className="w-5 h-5 animate-spin" /> Sending...</>
                  ) : (
                    <><Send className="w-5 h-5" /> Send Request</>
                  )}
                </button>
                {status === FormStatus.ERROR && (
                  <p className="text-red-500 text-sm text-center font-medium">Failed to send. Please check your connection or contact us on WhatsApp.</p>
                )}
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
