
import React from 'react';
import { useSite } from './SiteContext';
import { ICON_MAP } from '../constants';

const Services: React.FC = () => {
  const { config } = useSite();
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gold text-sm font-bold uppercase tracking-widest mb-3">Expert Solutions</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-navy mb-4">Our Services</h3>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            From minor repairs to medium renovations, we handle every aspect of property maintenance with precision and care.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {config.services.map((service) => (
            <div 
              key={service.id} 
              className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 group hover:-translate-y-2"
            >
              <div className="w-14 h-14 bg-gold bg-opacity-10 text-gold rounded-xl flex items-center justify-center mb-6 group-hover:bg-navy group-hover:text-white transition-colors duration-300">
                {ICON_MAP[service.iconName] || ICON_MAP['Wrench']}
              </div>
              <h4 className="text-xl font-bold text-navy mb-4">{service.title}</h4>
              <p className="text-gray-600 leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
