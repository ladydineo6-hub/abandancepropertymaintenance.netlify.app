
import React from 'react';
import { Phone, ClipboardList, BadgeDollarSign, Hammer, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: <Phone className="w-6 h-6" />,
    title: "Contact Us",
    description: "Reach out via WhatsApp, phone call, or online form."
  },
  {
    icon: <ClipboardList className="w-6 h-6" />,
    title: "Assessment",
    description: "We assess the issue on-site or via shared photos/videos."
  },
  {
    icon: <BadgeDollarSign className="w-6 h-6" />,
    title: "Quotation",
    description: "Receive a clear, honest quote with no hidden costs."
  },
  {
    icon: <Hammer className="w-6 h-6" />,
    title: "Professional Work",
    description: "Our skilled team completes the job efficiently."
  },
  {
    icon: <CheckCircle className="w-6 h-6" />,
    title: "Final Satisfaction",
    description: "Everything meets quality standards before sign-off."
  }
];

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gold text-sm font-bold uppercase tracking-widest mb-3">Simple Process</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-navy mb-4">How It Works</h3>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            We've streamlined our process to ensure your maintenance needs are handled with zero stress.
          </p>
        </div>

        <div className="relative">
          {/* Connector Line (Desktop) */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-100 hidden lg:block -translate-y-1/2 z-0"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 relative z-10">
            {steps.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-navy text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:bg-gold transition-colors duration-300 relative">
                  <span className="absolute -top-2 -right-2 bg-gold text-navy font-bold text-xs w-6 h-6 rounded-full flex items-center justify-center border-2 border-white">
                    {index + 1}
                  </span>
                  {step.icon}
                </div>
                <h4 className="text-lg font-bold text-navy mb-3">{step.title}</h4>
                <p className="text-sm text-gray-600 leading-relaxed px-4">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
