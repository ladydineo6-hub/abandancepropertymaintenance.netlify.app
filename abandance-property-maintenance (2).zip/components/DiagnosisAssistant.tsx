
import React, { useState } from 'react';
import { Bot, Sparkles, Send, Loader2 } from 'lucide-react';
import { diagnoseMaintenanceIssue } from '../services/geminiService';

const DiagnosisAssistant: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDiagnose = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const diagnosis = await diagnoseMaintenanceIssue(query);
      setResult(diagnosis);
    } catch (error) {
      setResult("Sorry, I encountered an error. Please contact us directly.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-24 bg-navy text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 opacity-10 pointer-events-none">
        <Sparkles className="w-96 h-96 -mr-20 -mt-20 text-gold" />
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold bg-opacity-20 rounded-full text-gold font-bold text-xs uppercase mb-4 border border-gold border-opacity-30">
            <Bot className="w-4 h-4" /> AI-Powered Assistant
          </div>
          <h3 className="text-3xl md:text-4xl font-bold mb-4 italic">Smart Maintenance Diagnosis</h3>
          <p className="text-gray-300 text-lg">
            Describe your property issue below, and our AI assistant will provide a preliminary diagnosis and 
            help you prepare for a more accurate quote.
          </p>
        </div>

        <div className="bg-white text-navy rounded-3xl p-6 md:p-10 shadow-2xl">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-navy uppercase tracking-wider mb-2">What seems to be the problem?</label>
              <div className="relative">
                <textarea 
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="e.g., My kitchen geyser is leaking from the top and making a loud humming sound..."
                  className="w-full h-32 px-5 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-gold focus:outline-none transition-all resize-none text-lg"
                />
                <button
                  onClick={handleDiagnose}
                  disabled={loading || !query.trim()}
                  className="absolute bottom-4 right-4 bg-gold text-white px-6 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-opacity-90 disabled:opacity-50 transition-all shadow-md"
                >
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  {loading ? 'Analyzing...' : 'Diagnose'}
                </button>
              </div>
            </div>

            {result && (
              <div className="animate-in fade-in slide-in-from-top-4 duration-500">
                <div className="p-6 bg-gold bg-opacity-5 rounded-2xl border-l-4 border-gold">
                  <h4 className="font-bold flex items-center gap-2 mb-3 text-gold">
                    <Bot className="w-5 h-5" /> AI Preliminary Diagnosis
                  </h4>
                  <div className="text-gray-700 whitespace-pre-line leading-relaxed italic">
                    {result}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiagnosisAssistant;
