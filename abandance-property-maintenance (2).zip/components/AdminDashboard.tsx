
import React, { useState } from 'react';
import { 
  Settings, Layout, FileText, Image as ImageIcon, 
  Palette, Eye, Save, RotateCcw, X, Plus, Trash2, 
  ChevronRight, Search, Globe, ChevronDown, Check
} from 'lucide-react';
import { useSite } from './SiteContext';
import { Service, BlogPost } from '../types';

const AdminDashboard: React.FC = () => {
  const { config, updateConfig, resetConfig, setIsAdmin } = useSite();
  const [activeTab, setActiveTab] = useState<'content' | 'design' | 'services' | 'blog' | 'seo'>('content');

  const updateDesign = (key: string, value: any) => {
    updateConfig({
      design: { ...config.design, [key]: value }
    });
  };

  const updateVisibility = (section: string, val: boolean) => {
    updateConfig({
      design: {
        ...config.design,
        sectionsVisibility: { ...config.design.sectionsVisibility, [section]: val }
      }
    });
  };

  return (
    <div className="fixed inset-0 z-[100] bg-gray-50 flex flex-col font-sans">
      {/* Header */}
      <header className="bg-navy text-white px-6 py-4 flex justify-between items-center shadow-lg">
        <div className="flex items-center gap-3">
          <div className="bg-gold p-2 rounded-lg">
            <Settings className="w-5 h-5 text-navy" />
          </div>
          <div>
            <h1 className="font-bold text-lg">Abandance CMS</h1>
            <p className="text-[10px] uppercase tracking-widest text-gold opacity-80">Admin Control Panel</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={resetConfig}
            className="text-xs flex items-center gap-1 opacity-70 hover:opacity-100 transition-opacity"
          >
            <RotateCcw className="w-4 h-4" /> Reset Defaults
          </button>
          <button 
            onClick={() => setIsAdmin(false)}
            className="bg-white text-navy px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-gray-100"
          >
            <Eye className="w-4 h-4" /> View Site
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 flex flex-col p-4 gap-2">
          <SidebarLink active={activeTab === 'content'} onClick={() => setActiveTab('content')} icon={<Layout className="w-4 h-4" />} label="General Content" />
          <SidebarLink active={activeTab === 'design'} onClick={() => setActiveTab('design')} icon={<Palette className="w-4 h-4" />} label="Design & Theme" />
          <SidebarLink active={activeTab === 'services'} onClick={() => setActiveTab('services')} icon={<Settings className="w-4 h-4" />} label="Services Manager" />
          <SidebarLink active={activeTab === 'blog'} onClick={() => setActiveTab('blog')} icon={<FileText className="w-4 h-4" />} label="Pages & Blog" />
          <SidebarLink active={activeTab === 'seo'} onClick={() => setActiveTab('seo')} icon={<Globe className="w-4 h-4" />} label="SEO Settings" />
        </aside>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-8 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            {activeTab === 'content' && <GeneralContentTab />}
            {activeTab === 'design' && <DesignTab />}
            {activeTab === 'services' && <ServicesTab />}
            {activeTab === 'blog' && <BlogTab />}
            {activeTab === 'seo' && <SEOTab />}
          </div>
        </main>
      </div>
    </div>
  );
};

const SidebarLink: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${active ? 'bg-navy text-white shadow-md' : 'text-gray-500 hover:bg-gray-100'}`}
  >
    {icon} {label}
  </button>
);

const GeneralContentTab: React.FC = () => {
  const { config, updateConfig } = useSite();
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2">
      <section className="bg-white p-6 rounded-2xl shadow-sm space-y-4">
        <h2 className="text-xl font-bold text-navy flex items-center gap-2 border-b pb-4">
          <Layout className="w-5 h-5 text-gold" /> Site Identity
        </h2>
        <div className="grid grid-cols-2 gap-4">
          <Input label="Company Name" value={config.companyName} onChange={v => updateConfig({ companyName: v })} />
          <Input label="Phone" value={config.phone} onChange={v => updateConfig({ phone: v })} />
          <Input label="Email" value={config.email} onChange={v => updateConfig({ email: v })} />
          <Input label="WhatsApp (Intl Format)" value={config.whatsappNumber} onChange={v => updateConfig({ whatsappNumber: v })} />
        </div>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow-sm space-y-4">
        <h2 className="text-xl font-bold text-navy flex items-center gap-2 border-b pb-4">
          <ImageIcon className="w-5 h-5 text-gold" /> Hero Section Content
        </h2>
        <Input label="Hero Title" value={config.hero.title} onChange={v => updateConfig({ hero: { ...config.hero, title: v } })} />
        <TextArea label="Hero Subtitle" value={config.hero.subtitle} onChange={v => updateConfig({ hero: { ...config.hero, subtitle: v } })} />
        <div className="grid grid-cols-2 gap-4">
          <Input label="Primary Button" value={config.hero.ctaPrimary} onChange={v => updateConfig({ hero: { ...config.hero, ctaPrimary: v } })} />
          <Input label="Secondary Button" value={config.hero.ctaSecondary} onChange={v => updateConfig({ hero: { ...config.hero, ctaSecondary: v } })} />
        </div>
        <Input label="Hero Background URL" value={config.hero.bgImage} onChange={v => updateConfig({ hero: { ...config.hero, bgImage: v } })} />
      </section>
    </div>
  );
};

const DesignTab: React.FC = () => {
  const { config, updateConfig } = useSite();
  
  const updateVisibility = (section: string, val: boolean) => {
    updateConfig({
      design: {
        ...config.design,
        sectionsVisibility: { ...config.design.sectionsVisibility, [section as any]: val }
      }
    });
  };

  return (
    <div className="space-y-8">
      <section className="bg-white p-6 rounded-2xl shadow-sm space-y-6">
        <h2 className="text-xl font-bold text-navy flex items-center gap-2 border-b pb-4">
          <Palette className="w-5 h-5 text-gold" /> Branding & Theme
        </h2>
        <div className="grid grid-cols-2 gap-8">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Primary Color</label>
            <div className="flex gap-2">
              <input 
                type="color" 
                value={config.design.primaryColor} 
                onChange={e => updateConfig({ design: { ...config.design, primaryColor: e.target.value } })}
                className="w-12 h-12 rounded-lg cursor-pointer"
              />
              <input 
                type="text" 
                value={config.design.primaryColor} 
                onChange={e => updateConfig({ design: { ...config.design, primaryColor: e.target.value } })}
                className="flex-1 px-3 py-2 border rounded-lg"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">Accent Color</label>
            <div className="flex gap-2">
              <input 
                type="color" 
                value={config.design.accentColor} 
                onChange={e => updateConfig({ design: { ...config.design, accentColor: e.target.value } })}
                className="w-12 h-12 rounded-lg cursor-pointer"
              />
              <input 
                type="text" 
                value={config.design.accentColor} 
                onChange={e => updateConfig({ design: { ...config.design, accentColor: e.target.value } })}
                className="flex-1 px-3 py-2 border rounded-lg"
              />
            </div>
          </div>
        </div>
        <div>
          <label className="block text-sm font-bold text-gray-700 mb-2">Font Family</label>
          <select 
            value={config.design.fontFamily}
            onChange={e => updateConfig({ design: { ...config.design, fontFamily: e.target.value as any } })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-navy"
          >
            <option value="Inter">Inter (Modern & Clean)</option>
            <option value="Montserrat">Montserrat (Geometric)</option>
            <option value="Playfair Display">Playfair Display (Elegant Serif)</option>
            <option value="Roboto">Roboto (Systemic)</option>
          </select>
        </div>
      </section>

      <section className="bg-white p-6 rounded-2xl shadow-sm space-y-4">
        <h2 className="text-xl font-bold text-navy flex items-center gap-2 border-b pb-4">
          <Layout className="w-5 h-5 text-gold" /> Page Section Visibility
        </h2>
        <div className="grid grid-cols-2 gap-x-12 gap-y-4">
          {Object.entries(config.design.sectionsVisibility).map(([section, visible]) => (
            <div key={section} className="flex justify-between items-center p-3 hover:bg-gray-50 rounded-lg transition-colors">
              <span className="capitalize text-sm font-medium text-gray-700">{section.replace(/([A-Z])/g, ' $1')}</span>
              <Toggle checked={visible} onChange={v => updateVisibility(section, v)} />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const ServicesTab: React.FC = () => {
  const { config, updateConfig } = useSite();
  const [editingId, setEditingId] = useState<string | null>(null);

  const addService = () => {
    const newService: Service = {
      id: Math.random().toString(36).substr(2, 9),
      title: "New Service",
      description: "Service description here.",
      iconName: "Wrench"
    };
    updateConfig({ services: [...config.services, newService] });
    setEditingId(newService.id);
  };

  const removeService = (id: string) => {
    if (confirm("Delete this service?")) {
      updateConfig({ services: config.services.filter(s => s.id !== id) });
    }
  };

  const updateService = (id: string, updates: Partial<Service>) => {
    updateConfig({
      services: config.services.map(s => s.id === id ? { ...s, ...updates } : s)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-navy">Manage Services</h2>
        <button onClick={addService} className="bg-navy text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-opacity-90">
          <Plus className="w-4 h-4" /> Add Service
        </button>
      </div>

      <div className="grid gap-4">
        {config.services.map(s => (
          <div key={s.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="bg-gray-100 p-2 rounded-lg">{s.iconName}</div>
                <h3 className="font-bold text-navy">{s.title}</h3>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setEditingId(editingId === s.id ? null : s.id)} className="text-gray-400 hover:text-navy transition-colors">
                  <Settings className="w-4 h-4" />
                </button>
                <button onClick={() => removeService(s.id)} className="text-red-300 hover:text-red-500 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            {editingId === s.id && (
              <div className="mt-4 pt-4 border-t grid grid-cols-2 gap-4 animate-in fade-in zoom-in duration-200">
                <Input label="Title" value={s.title} onChange={v => updateService(s.id, { title: v })} />
                <Input label="Icon Name" value={s.iconName} onChange={v => updateService(s.id, { iconName: v })} />
                <div className="col-span-2">
                  <TextArea label="Description" value={s.description} onChange={v => updateService(s.id, { description: v })} />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const BlogTab: React.FC = () => {
  const { config, updateConfig } = useSite();
  const [editingId, setEditingId] = useState<string | null>(null);

  const addPost = () => {
    const newPost: BlogPost = {
      id: Math.random().toString(36).substr(2, 9),
      title: "New Page/Post",
      content: "Content goes here...",
      slug: "new-post",
      category: "Uncategorized",
      status: 'draft',
      author: 'Admin',
      date: new Date().toLocaleDateString(),
      seo: { metaTitle: '', metaDescription: '', urlSlug: '' }
    };
    updateConfig({ posts: [...config.posts, newPost] });
    setEditingId(newPost.id);
  };

  const updatePost = (id: string, updates: Partial<BlogPost>) => {
    updateConfig({
      posts: config.posts.map(p => p.id === id ? { ...p, ...updates } : p)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-navy">Content Manager</h2>
        <button onClick={addPost} className="bg-navy text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-opacity-90">
          <Plus className="w-4 h-4" /> New Post/Page
        </button>
      </div>

      <div className="space-y-4">
        {config.posts.map(p => (
          <div key={p.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${p.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {p.status}
                  </span>
                  <span className="text-xs text-gray-400">{p.date}</span>
                </div>
                <h3 className="text-lg font-bold text-navy">{p.title}</h3>
              </div>
              <div className="flex gap-2">
                <button onClick={() => setEditingId(editingId === p.id ? null : p.id)} className="bg-gray-50 hover:bg-navy hover:text-white p-2 rounded-lg transition-all">
                  <FileText className="w-4 h-4" />
                </button>
                <button onClick={() => updateConfig({ posts: config.posts.filter(item => item.id !== p.id) })} className="p-2 text-red-300 hover:text-red-500 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            {editingId === p.id && (
              <div className="mt-6 pt-6 border-t space-y-4 animate-in slide-in-from-top-2 duration-300">
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Post Title" value={p.title} onChange={v => updatePost(p.id, { title: v })} />
                  <Input label="Slug" value={p.slug} onChange={v => updatePost(p.id, { slug: v })} />
                  <select 
                    value={p.status}
                    onChange={e => updatePost(p.id, { status: e.target.value as any })}
                    className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-navy"
                  >
                    <option value="draft">Draft</option>
                    <option value="published">Published</option>
                  </select>
                  <Input label="Category" value={p.category} onChange={v => updatePost(p.id, { category: v })} />
                </div>
                <TextArea label="Body Content" rows={10} value={p.content} onChange={v => updatePost(p.id, { content: v })} />
                <div className="bg-gray-50 p-4 rounded-xl space-y-3">
                  <h4 className="text-xs font-bold text-gray-500 uppercase">SEO Override for this Post</h4>
                  <Input label="Meta Title" value={p.seo.metaTitle} onChange={v => updatePost(p.id, { seo: { ...p.seo, metaTitle: v } })} />
                  <TextArea label="Meta Description" value={p.seo.metaDescription} onChange={v => updatePost(p.id, { seo: { ...p.seo, metaDescription: v } })} />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const SEOTab: React.FC = () => {
  const { config, updateConfig } = useSite();
  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm space-y-6">
       <h2 className="text-2xl font-bold text-navy flex items-center gap-2">
          <Globe className="w-6 h-6 text-gold" /> Search Engine Optimization
       </h2>
       <p className="text-gray-500 text-sm">Configure how search engines like Google see your website.</p>
       <div className="space-y-6 mt-8">
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
            <h3 className="text-blue-800 font-bold mb-1">Google Search Preview</h3>
            <p className="text-blue-600 text-xl hover:underline cursor-pointer truncate">
              {config.companyName} | {config.hero.title}
            </p>
            <p className="text-green-700 text-sm truncate">https://abandancemaintenance.co.za/</p>
            <p className="text-gray-600 text-sm line-clamp-2 mt-1">
              {config.hero.subtitle}
            </p>
          </div>

          <Input label="Global Site Title" value={config.companyName} onChange={v => updateConfig({ companyName: v })} />
          <TextArea label="Global Meta Description" value={config.hero.subtitle} onChange={v => updateConfig({ hero: { ...config.hero, subtitle: v } })} />
       </div>
    </div>
  );
};

// UI Components
const Input: React.FC<{ label: string; value: string; onChange: (val: string) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-1">
    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider">{label}</label>
    <input 
      type="text" 
      value={value} 
      onChange={e => onChange(e.target.value)}
      className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-navy outline-none transition-all text-sm"
    />
  </div>
);

const TextArea: React.FC<{ label: string; value: string; onChange: (val: string) => void; rows?: number }> = ({ label, value, onChange, rows = 3 }) => (
  <div className="space-y-1">
    <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider">{label}</label>
    <textarea 
      value={value} 
      onChange={e => onChange(e.target.value)}
      rows={rows}
      className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-navy outline-none transition-all text-sm resize-none"
    />
  </div>
);

const Toggle: React.FC<{ checked: boolean; onChange: (val: boolean) => void }> = ({ checked, onChange }) => (
  <button 
    onClick={() => onChange(!checked)}
    className={`w-12 h-6 rounded-full relative transition-colors duration-300 ${checked ? 'bg-navy' : 'bg-gray-300'}`}
  >
    <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-all duration-300 ${checked ? 'translate-x-6' : 'translate-x-0'}`} />
  </button>
);

export default AdminDashboard;
