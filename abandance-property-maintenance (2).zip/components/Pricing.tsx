
import React from 'react';
import { Tag, Clock, Calculator, ShieldCheck } from 'lucide-react';

const Pricing: React.FC = () => {
  const details = [
    { icon: <Tag className="text-gold" />, label: "Call-out fees where applicable" },
    { icon: <Clock className="text-gold" />, label: "Hourly or project-based pricing" },
    { icon: <Calculator className="text-gold" />, label: "Custom quotes for renovations" },
    { icon: <ShieldCheck className="text-gold" />, label: "No hidden costs, full transparency" }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-navy rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 lg:p-20 text-white flex flex-col justify-center">
            <h2 className="text-gold text-sm font-bold uppercase tracking-widest mb-4">Honest Value</h2>
            <h3 className="text-4xl md:text-5xl font-bold mb-8">Fair & Competitive Pricing</h3>
            <p className="text-gray-300 text-lg mb-10 leading-relaxed">
              We believe in transparent billing. Whether it's a small fix or a major upgrade, we discuss all 
              costs upfront so there are no surprises on your final invoice.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {details.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="p-2 bg-white bg-opacity-10 rounded-lg">{item.icon}</div>
                  <span className="font-medium text-sm sm:text-base">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="lg:w-1/2 relative min-h-[400px]">
            <img 
              src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000" 
              className="w-full h-full object-cover grayscale-[30%] hover:grayscale-0 transition-all duration-700" 
              alt="Workman" 
            />
            <div className="absolute inset-0 bg-gold opacity-10 mix-blend-multiply"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
