
export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Testimonial {
  name: string;
  role: string;
  text: string;
}

export enum FormStatus {
  IDLE = 'IDLE',
  SUBMITTING = 'SUBMITTING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export interface SiteSEO {
  metaTitle: string;
  metaDescription: string;
  urlSlug: string;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  slug: string;
  category: string;
  status: 'draft' | 'published';
  author: string;
  date: string;
  image?: string;
  seo: SiteSEO;
}

export interface SiteDesign {
  primaryColor: string;
  accentColor: string;
  fontFamily: 'Inter' | 'Playfair Display' | 'Roboto' | 'Montserrat';
  borderRadius: 'none' | 'sm' | 'md' | 'lg' | 'full';
  sectionsVisibility: {
    hero: boolean;
    services: boolean;
    howItWorks: boolean;
    diagnosis: boolean;
    whyChooseUs: boolean;
    whoWeServe: boolean;
    pricing: boolean;
    testimonials: boolean;
    faq: boolean;
    contact: boolean;
  };
}

export interface SiteConfig {
  companyName: string;
  phone: string;
  email: string;
  whatsappNumber: string;
  address: string;
  hero: {
    title: string;
    subtitle: string;
    ctaPrimary: string;
    ctaSecondary: string;
    bgImage: string;
  };
  services: Service[];
  faqs: FAQItem[];
  testimonials: Testimonial[];
  design: SiteDesign;
  posts: BlogPost[];
}
