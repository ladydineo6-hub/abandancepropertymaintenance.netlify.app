
import React from 'react';
import { 
  Wrench, Droplets, Zap, Paintbrush, Grid3X3, Hammer, 
  ShieldAlert, DoorOpen, Construction, Star, Building2, 
  UserCircle, Briefcase 
} from 'lucide-react';
import { SiteConfig } from './types';

export const ICON_MAP: Record<string, React.ReactNode> = {
  Wrench: <Wrench className="w-5 h-5" />,
  Droplets: <Droplets className="w-5 h-5" />,
  Zap: <Zap className="w-5 h-5" />,
  Paintbrush: <Paintbrush className="w-5 h-5" />,
  Grid3X3: <Grid3X3 className="w-5 h-5" />,
  Hammer: <Hammer className="w-5 h-5" />,
  ShieldAlert: <ShieldAlert className="w-5 h-5" />,
  DoorOpen: <DoorOpen className="w-5 h-5" />,
  Construction: <Construction className="w-5 h-5" />,
  Star: <Star className="w-5 h-5" />,
  Building2: <Building2 className="w-5 h-5" />,
  UserCircle: <UserCircle className="w-5 h-5" />,
  Briefcase: <Briefcase className="w-5 h-5" />
};

export const INITIAL_SITE_CONFIG: SiteConfig = {
  companyName: "Abandance Property Maintenance",
  phone: "071 169 1676",
  email: "ladydineo6@gmail.com",
  whatsappNumber: "27711691676",
  address: "South Africa (Local & Surrounding Areas)",
  hero: {
    title: "Property Maintenance You Can Trust.",
    subtitle: "Abandance Property Maintenance provides high-quality repairs and renovations for homes, rentals, and businesses across South Africa.",
    ctaPrimary: "Request a Free Quote",
    ctaSecondary: "WhatsApp Us",
    bgImage: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&q=80&w=2000"
  },
  design: {
    primaryColor: "#1e3a5f",
    accentColor: "#d4a853",
    fontFamily: "Inter",
    borderRadius: "lg",
    sectionsVisibility: {
      hero: true,
      services: true,
      howItWorks: true,
      diagnosis: true,
      whyChooseUs: true,
      whoWeServe: true,
      pricing: true,
      testimonials: true,
      faq: true,
      contact: true
    }
  },
  services: [
    { id: '1', title: 'General Property Maintenance', description: 'Ongoing upkeep and minor repairs to keep your property safe.', iconName: 'Wrench' },
    { id: '2', title: 'Plumbing Services', description: 'Leak repairs, blocked drains, and geyser-related work.', iconName: 'Droplets' },
    { id: '3', title: 'Electrical Services', description: 'Fault finding, light fittings, plugs, and DB checks.', iconName: 'Zap' },
    { id: '4', title: 'Painting', description: 'Interior and exterior painting for homes and offices.', iconName: 'Paintbrush' },
    { id: '5', title: 'Tiling', description: 'Floor and wall tiling for bathrooms and kitchens.', iconName: 'Grid3X3' },
    { id: '6', title: 'Renovations', description: 'Small to medium renovations including room upgrades.', iconName: 'Construction' }
  ],
  faqs: [
    { question: "Do you offer free quotes?", answer: "Yes, we provide free quotations based on assessments." },
    { question: "Which areas do you service?", answer: "We service local and surrounding areas within South Africa." }
  ],
  testimonials: [
    { name: "John Doe", role: "Homeowner", text: "Professional, reliable, and affordable. Handled our repairs efficiently." },
    { name: "Sarah Smith", role: "Property Manager", text: "Great workmanship and excellent communication. Highly recommended." }
  ],
  posts: [
    {
      id: 'p1',
      title: 'How to Maintain Your Geyser',
      content: 'Regular geyser maintenance can save you thousands in electricity and repair costs...',
      slug: 'how-to-maintain-geyser',
      category: 'Maintenance Tips',
      status: 'published',
      author: 'Admin',
      date: new Date().toLocaleDateString(),
      seo: { metaTitle: 'Geyser Maintenance Tips', metaDescription: 'Learn how to maintain your geyser.', urlSlug: 'geyser-maintenance' }
    }
  ]
};

// Add missing constants to resolve module export errors
export const FORMSPREE_URL = "https://formspree.io/f/mdkaowpq";
export const PHONE = INITIAL_SITE_CONFIG.phone;
export const EMAIL = INITIAL_SITE_CONFIG.email;
export const COMPANY_NAME = INITIAL_SITE_CONFIG.companyName;
