
import { GoogleGenAI } from "@google/genai";

export async function diagnoseMaintenanceIssue(description: string): Promise<string> {
  // Use process.env.API_KEY directly as per guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    // Calling generateContent directly with the required parameters.
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are an expert maintenance advisor for Abandance Property Maintenance. 
      The user describes a problem: "${description}".
      1. Provide a brief 2-3 sentence preliminary diagnosis.
      2. Suggest if it is an emergency or standard repair.
      3. List 2-3 specific questions they should answer to get a better quote.
      Keep the tone professional and helpful. End with "Please use our quote form below to get an official assessment."`,
      config: {
        temperature: 0.7,
        // Removed maxOutputTokens to prevent potential truncation as per guidelines for basic tasks.
      }
    });

    // Access the text property directly from the response object.
    return response.text || "I couldn't process that description. Please call us for a direct consultation.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error connecting to the AI assistant. Please contact us via WhatsApp.";
  }
}
